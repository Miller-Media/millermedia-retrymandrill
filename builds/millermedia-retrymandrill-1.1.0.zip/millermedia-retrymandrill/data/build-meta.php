<?php
return <<<'JSON'
{
    "framework_version": "2.2.2",
    "framework_bundled": true
}
JSON;
