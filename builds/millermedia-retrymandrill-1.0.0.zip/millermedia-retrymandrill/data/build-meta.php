<?php
return <<<'JSON'
{
    "framework_version": "2.2.1",
    "framework_bundled": true
}
JSON;
