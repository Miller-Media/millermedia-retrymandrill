<?php
return <<<'JSON'
{
    "vendor": "Miller Media",
    "namespace": "MillerMedia\\RetryMandrill",
    "name": "retry-emails-with-mandrill",
    "slug": "millermedia-retrymandrill",
    "version": "1.0.0"
}
JSON;
