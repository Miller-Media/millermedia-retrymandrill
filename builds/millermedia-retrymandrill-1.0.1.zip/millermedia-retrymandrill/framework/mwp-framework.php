<?php

require_once 'plugin.php';