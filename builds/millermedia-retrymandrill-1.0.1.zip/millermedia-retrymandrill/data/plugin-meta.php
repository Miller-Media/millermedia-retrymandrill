<?php
return <<<'JSON'
{
    "vendor": "Miller Media",
    "namespace": "MillerMedia\\RetryMandrill",
    "name": "Retry Emails (Send Emails with Mandrill extension)",
    "slug": "millermedia-retrymandrill",
    "version": "1.0.1",
    "description": "Queues up failed Mandrill API calls by queuing",
    "author": "Miller Media",
    "author_url": "http:\/\/www.millermedia.io"
}
JSON;
